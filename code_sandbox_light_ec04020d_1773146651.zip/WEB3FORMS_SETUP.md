# Web3Forms セットアップ手順

## ステップ1: アクセスキーを取得（1分）

1. **Web3Formsにアクセス**
   - https://web3forms.com/

2. **「Get Started」をクリック**

3. **メールアドレスを入力**
   - `taishi.73767123@gmail.com`
   - 「Get Your Access Key」をクリック

4. **メールを確認**
   - Gmailに届いたメールを開く
   - **Access Key（アクセスキー）をコピー**
   - 例: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

5. **このAccess Keyを教えてください**

---

## ステップ2: HTMLを修正（私が行います）

Access Keyを教えていただいたら、すぐにHTMLを修正してデプロイします！

---

## ⏱️ 所要時間：2分
## ✅ 確実に動作します！